/**
 * File Name: HKGlobal.js
 *
 * Revision History:
 *       Harmandeep Kaur, 2018-04-21 : Created
 */

function btnOK_click() {
    testValidations();
}
function btnUpdate_click() {
    updateValidations();
}
function HKSelectedItemsPage_click() {
    
}
function HKModifyMenuPage_click(){

}

function init() {
    $("#btnOK").on("click", btnOK_click);
    $("#HKUpdate").on("click", btnUpdate_click);
    
    $("#HKSelectedItemsPage").on("pageshow", HKSelectedItemsPage_click);
    $("#HKModifyMenuPage").on("pageshow", HKModifyMenuPage_click);
}

function initDB(){
    console.info("Creating database ...");
    try {
        DB.HKCreateDatabase();
        if (db) {
            console.info("Creating tables ... ");
            DB.HKCreateTables();
        }
    } catch (e) {
        console.error("Error: (Fatal) Error in initDB(). Can not proceed.");
    }
}



$(document).ready(function () {
    init();
    initDB();
});
