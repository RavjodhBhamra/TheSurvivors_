/**
 * File Name: HKUtil.js
 *
 * Revision History:
 *       Harmandeep Kaur, 2018-04-21 : Created
 */

function testValidations(){
    if (doValidate_frmMenu()) {
        var customerName = $("#txtCustomerName").val();
        var email = $("#txtEmail").val();
        var eatingPlace = $("#txtEatingPlace").val();
        var date = $("#HKDate").val();
        var time = $("#HKTime").val();
        var foodType = $("#txtFoodType").val();
    }
    else {
        console.error("Validation failed");
    }
}

function doValidate_frmMenu() {
    var form= $("#frmMenu");
    form.validate({
        rules: {
            txtCustomerName: {
                required: true,
                rangelength: [2, 50]
            },
            txtEmail: {
                required: true,
                emailcheck: true
            },
            txtEatingPlace: {
                required: true
            },
            HKDate: {
                required: true
            },
            HKTime: {
                required: true
            },
            txtFoodType: {
                required: true
            }
        },
        messages: {
            txtCustomerName: {
                required: "Customer Name is required",
                rangelength: "Customer name must be 2 to 50 characters long"
            },
            txtEmail: {
                required: "Customer Email is required",
                emailcheck: "Email must be valid"
            },
            txtEatingPlace: {
                required: "You must specify eating place"
            },
            HKDate: {
                required: "Date of order is required"
            },
            HKTime: {
                required: "Time of order is required"
            },
            txtFoodType: {
                required: "Food Type is required"
            }
        }
    });
    return form.valid();
}

function updateValidations(){
    if(doValidate_frmMenuModify()) {
        var modifiedCustomerName = $("#txtCustomerNameModify").val();
        var modifiedEmail = $("#txtEmailModify").val();
        var modifiedEatingPlace = $("#txtEatingPlaceModify").val();
        var modifiedDate = $("#HKDateModify").val();
        var modifiedTime = $("#HKTimeModify").val();
        var modifiedFoodType = $("#txtFoodTypeModify").val();
    }
    else {
        console.error("Validation failed");
    }
}

function doValidate_frmMenuModify() {
    var form = $("#frmMenuModify");
    form.validate({
        rules: {
            txtCustomerNameModify: {
                required: true,
                rangelength: [2, 50]
            },
            txtEmailModify: {
                required: true,
                emailcheck: true
            },
            txtEatingPlaceModify: {
                required: true
            },
            HKDateModify: {
                required: true
            },
            HKTimeModify:{
                required: true
            },
            txtFoodTypeModify: {
                required: true
            }
        },
        messages: {
            txtCustomerNameModify: {
                required: "Customer Name is required",
                rangelength: "Customer name must be 2 to 50 characters long"
            },
            txtEmailModify: {
                required: "Customer Email is required",
                emailcheck: "Email must be valid"
            },
            txtEatingPlaceModify: {
                required: "You must specify eating place"
            },
            HKDateModify: {
                required: "Date of order is required"
            },
            HKTimeModify:{
                required: "Time of order is required"
            },
            txtFoodTypeModify: {
                required: "Food Type is required"
            }
        }
    });
    return form.valid();
}

jQuery.validator.addMethod("emailcheck",
    function (value, element) {
        var regex = /^(([^<>()\[\]\.,;:\s@\"]+(\.[^<>()\[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/i;
        return this.optional(element) || regex.test(value);
    },
    "Email must be valid");

