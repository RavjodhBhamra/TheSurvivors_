/**
 * File Name: HKDatabase.js
 *
 * Revision History:
 *       Harmandeep Kaur, 2018-04-21 : Created
 */

var db;

/**
 * General purpose error handler callback
 * @param tx The transaction object
 * @param error The error object
 */
function errorHandler(tx, error) {
    console.error("SQL error: " + tx + " (" + error.code + ") : " + error.message);
}

var DB = {

    HKCreateDatabase: function () {
        var shortName = "HKFoodAppDB";
        var version = "1.0";
        var displayName = "DB for Final Project app";
        var dbSize = 2 * 1024 * 1024;

        function dbCreateSuccess() {
            console.info("Success: Database creation successful.");

        }

        db = openDatabase(shortName, version, displayName, dbSize, dbCreateSuccess);
    },
    HKCreateTables: function () {
        function txFunction(tx) {
            var HKDropTableStarter = "DROP TABLE IF EXISTS starter;";

            var sql1 = "CREATE TABLE IF NOT EXISTS starter(" +
                "id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT," +
                "name VARCHAR(20) NOT NULL;";

            var insertStarter = "INSERT INTO starter(name) VALUES(?);";

            var sql = "CREATE TABLE IF NOT EXISTS food(" +
                "id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, " +
                "customerName VARCHAR(50) NOT NULL, " +
                "email VARCHAR(50) NOT NULL," +
                "eatingPlace VARCHAR(20)," +
                "date DATE, " +
                "time TIME," +
                "foodType VARCHAR(20)" +
                "appetizer VARCHAR(20)" +
                "mainMenu VARCHAR(20)" +
                "dessert VARCHAR(20)," +
                "FOREIGN KEY(starterId) REFERENCES starter(id);";

            var options = [];

            function successCreate() {
                console.info("Success: Table creation successful");
            }

            tx.executeSql(sql1, options, successCreate, errorHandler);
            tx.executeSql(HKDropTableStarter, options, successCreate, errorHandler);
            tx.executeSql(sql, options, successCreate, errorHandler);
        }

        function successTransaction() {
            console.info("Success: Create table transaction successful");
        }

        db.transaction(txFunction, errorHandler, successTransaction);
    },

    HKDropTables: function () {
        function txFunction(tx) {
            var sql = "DROP TABLE IF EXISTS food;";
            var sql1 = "DROP TABLE IF EXISTS starter;";
            var options = [];

            function successDrop() {
                console.info("Success: Dropping Table successful.");
            }

            tx.executeSql(sql, options, successDrop, errorHandler);
            tx.executeSql(sql1, options, successDrop, errorHandler);
        }

        function successTransaction() {
            console.info("Success: Table drop transaction successful");


        }

        db.transaction(txFunction, errorHandler, successTransaction);

    }

};