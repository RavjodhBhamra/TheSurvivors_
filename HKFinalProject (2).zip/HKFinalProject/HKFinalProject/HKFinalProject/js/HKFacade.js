/**
 * File Name: HKFacade.js
 *
 * Revision History:
 *       Harmandeep Kaur, 2018-04-21 : Created
 */

function HKClearDatabase() {
    var result = confirm("Really want to clear database?");
    if (result) {
        try {
            DB.HKDropTables();
            alert("Database cleared");
        } catch (e) {
            alert(e);
        }
    }
}

function HKDeleteOrder(){
    var id = localStorage.getItem("id");
    var options= [id];
    function callback(){
        console.info("Success: Record deleted successfully");
        alert("Order deleted successfully");
        $.mobile.changePage("HKSelectedItemPage", {transition: 'none'});
    }
    Food.HKDelete(options, callback);
}