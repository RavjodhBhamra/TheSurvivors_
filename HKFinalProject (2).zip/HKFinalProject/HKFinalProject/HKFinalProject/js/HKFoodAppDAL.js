/**
 * File Name: HKFoodAppDAL.js
 *
 * Revision History:
 *       Harmandeep Kaur, 2018-04-21 : Created
 */

var Food = {
    HKInsert: function (options, callback) {
        function txFunction(tx) {
            var sql = "INSERT INTO food(customerName, email, eatingPlace, date, time, foodType, appetizer, mainMenu, dessert) VALUES(?,?,?,?,?,?,?,?,?);";
            tx.executeSql(sql, options, callback, errorHandler);
        }

        function successTransaction() {
            console.info("Success: insert transaction successful");
        }

        db.transaction(txFunction, errorHandler, successTransaction);
    },

    HKSelectAll: function (options, callback) {
        function txFunction(tx) {
            var sql = "SELECT * FROM food;";
            tx.executeSql(sql, options, callback, errorHandler);
        }

        function successTransaction() {
            console.info("Success: select all transaction successful");
        }

        db.transaction(txFunction, errorHandler, successTransaction);
    },
    HKSelect: function (options, callback) {
        function txFunction(tx) {
            var sql = "SELECT * FROM food WHERE id = ?;";

            tx.executeSql(sql, options, callback, errorHandler);
        }

        function successTransaction() {
            console.info("Success: select transaction successful");
        }

        db.transaction(txFunction, errorHandler, successTransaction
    },
    HKUpdate: function (options, callback) {
        function txFunction(tx) {
            var sql = "UPDATE food SET customerName=?, email=?, eatingPlace=?, date=?, time=?, foodType=?, appetizer=?, mainMenu=?, dessert=? WHERE id = ?;";
            tx.executeSql(sql, options, callback, errorHandler);

        }

        function successTransaction() {
            console.info("Success: transaction update successfully");
        }

        db.transaction(txFunction, errorHandler, successTransaction);
    },
    HKDelete: function (options, callback) {
        function txFunction(tx) {
            var sql = "DELETE FROM food WHERE id = ?;";

            tx.executeSql(sql, options, callback, errorHandler);
        }

        function successTransaction() {
            console.info("Success: Transaction deleted successfully");
        }

        db.transaction(txFunction, errorHandler, successTransaction);
    }
};

var Starter = {
    HKSelectAll: function (options, callback) {
        function txFunction(tx) {
            var sql1 = "SELECT * FROM starter;";
            tx.executeSql(sql1, options, callback, errorHandler);
        }


    function successTransaction() {
    console.info("Success: Transaction deleted successfully");
}

db.transaction(txFunction, errorHandler, successTransaction);
}
};